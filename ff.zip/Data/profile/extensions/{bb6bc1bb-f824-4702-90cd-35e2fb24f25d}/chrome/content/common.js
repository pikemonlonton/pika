const {classes: Cc, interfaces: Ci, utils: Cu} = Components;
Cu.import("resource://cookiesmanagerplus/coomanPlusCore.jsm");
var log = coomanPlusCore.log;