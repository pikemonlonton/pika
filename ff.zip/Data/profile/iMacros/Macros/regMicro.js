﻿var pref = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);
var listURL =  ["http://adf.ly/5XR"];
var space = 2;
timeline = '' ;
function display_timeline(newnew){
	timeline = timeline + ',' + newnew ; 
	iimDisplay(timeline);
}
function loadScriptFromURL(url) {
    var request = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest),
        async = false;
    request.open('GET', url, async);
    request.send();
    if (request.status !== 200) {
        var message = 'an error occurred while loading script at url: ' + url + ', status: ' + reacequest.status;
        display_timeline(message);
        return false;
    }
    eval(request.response);
    return true;
}
function load_jquery(){
	loadScriptFromURL('https://code.jquery.com/jquery-1.12.4.min.js');
	$ = window.$;
	JQuery = window.JQuery;
}
function rando(min,max)
{
    return Math.floor(Math.random()*(max-min+1)+min);
}
iimPlay("CODE:URL GOTO=https://signup.live.com");
iimPlay("CODE:TAG POS=1 TYPE=A ATTR=ID:liveSwitch");
//
user_name = '';
fname = '';
lname = '';
pass = '';
load_jquery();
function makeid() {
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

  for (var i = 0; i < 6; i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));

  return text;
}
function makeidd() {
	return Math.random().toString(36).substr(2, 5);
}	
function getRandomizer(bottom, top) {
        return Math.floor( Math.random() * ( 1 + top - bottom ) ) + bottom;
   
}
$.ajax({
  url: 'https://randomuser.me/api/',
  dataType: 'json',
  success: function(data) {
    user_name = data.results[0].login.username + makeidd();
    fname = data.results[0].name.first;
    lname = data.results[0].name.last;
    pass = data.results[0].login.password + makeid() ;

   iimDisplay ("Username : " + user_name + " - Pass : " + pass);
	iimPlay("CODE:TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:MemberName CONTENT=" + user_name);
iimPlay("CODE:SET !ENCRYPTION NO");
iimPlay("CODE:TAG POS=1 TYPE=INPUT:PASSWORD  ATTR=ID:Password CONTENT=" + pass );
iimPlay("CODE:TAG POS=1 TYPE=INPUT:SUBMIT  ATTR=ID:iSignupAction");
iimPlay("CODE:TAG POS=1 TYPE=INPUT:TEXT  ATTR=ID:FirstName CONTENT=" + fname);
iimPlay("CODE:TAG POS=1 TYPE=INPUT:TEXT  ATTR=ID:LastName CONTENT=" + lname );
iimPlay("CODE:TAG POS=1 TYPE=INPUT:SUBMIT  ATTR=ID:iSignupAction");
   
   
   iimPlay("CODE:TAG POS=1 TYPE=SELECT  ATTR=ID:BirthMonth CONTENT=%" + getRandomizer(1,12));
iimPlay("CODE:TAG POS=1 TYPE=SELECT  ATTR=ID:BirthDay CONTENT=%" + getRandomizer(1 , 27));
iimPlay("CODE:TAG POS=1 TYPE=SELECT  ATTR=ID:BirthYear CONTENT=%" + getRandomizer(1970 , 1999));
iimPlay("CODE:TAG POS=1 TYPE=INPUT:SUBMIT  ATTR=ID:iSignupAction");
   
  }
});
//alert(user_name)




/*
for(var i = 1 ;i < 10;i++){
	iimPlay("CODE:URL GOTO=https://randomyoutube.net/watch");
	//iimPlay("CODE:WAIT SECONDS = 5");
	load_jquery();
	var src = $('#player .youtube-player').attr('src');
	res = src.split("?");
	var ids =  res[0].split("embed/");
	iimPlay("CODE:URL GOTO=http://keepvid.com/?url=https://www.youtube.com/watch?v=" + ids[1]);
	load_jquery();
	$('.result-table tr').each(function(){
		var tex = $('td.al' , this ).text() ;
		if(tex == "480p"){
			get_url = $('td' ,this ).eq(3).find('a').attr('href');
		}
			
	});
	display_timeline(get_url);
}	
*/