﻿var pref = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);
var listURL =  ["http://adf.ly/5XR"];
var space = 9;
function loadScriptFromURL(url) {
    var request = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest),
        async = false;
    request.open('GET', url, async);
    request.send();
    if (request.status !== 200) {
        var message = 'an error occurred while loading script at url: ' + url + ', status: ' + reacequest.status;
        display_timeline(message);
        return false;
    }
    eval(request.response);
    return true;
}
function load_jquery(){
	loadScriptFromURL('https://code.jquery.com/jquery-1.12.4.min.js');
	$ = window.$;
	JQuery = window.JQuery;
}
function rando(min,max)
{
    return Math.floor(Math.random()*(max-min+1)+min);
}
function fakesock(sock){
	var ip= sock.split(':');
    var a = pref.getBranch("network.proxy.");
	 a. setCharPref("socks", ip[0]);
 	a.setIntPref("socks_port", ip[1]);
 	a.setIntPref("type", 1);
}
function resetsock(){
	
    var a = pref.getBranch("network.proxy.");
	 a. setCharPref("socks", '0');
 	a.setIntPref("socks_port", '0');
 	a.setIntPref("type", 1);
}
function getsock(type){

	var xhr = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest);

	xhr.open('POST', 'http://localhost/test/sock/cr.php', false);
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	var params = "action=" + type;
	xhr.send(params);
//	xhr.onload = function(e) {
	  if (xhr.status == 200) {
	    var myBlob = xhr.response;
	   	return myBlob;
	  }
//	};
	
}

function makeid() {
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

  for (var i = 0; i < 6; i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));

  return text;
}
function makeidd() {
	return Math.random().toString(36).substr(2, 5);
}	
function getRandomizer(bottom, top) {
        return Math.floor( Math.random() * ( 1 + top - bottom ) ) + bottom;
   
}
function checklive(){
	var xhr = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest);

	xhr.open('GET', 'https://assets.onestore.ms/cdnfiles/external/uhf/long/9a49a7e9d8e881327e81b9eb43dabc01de70a9bb/images/microsoft-gray.png', false);
	xhr.send();
	var myBlob = '' ;
	if (xhr.status == 200) {
	    var myBlob = xhr.response;
//	    alert(myBlob);
	  // 	return myBlob;
	}
	if(myBlob != ''){
		return true ;
	//	checkli = true ;
	}
	else{
		return false ;
	}
}
function checklive2(){
//	iimPlay("CODE:SET !TIMEOUT_PAGE 5\n");
	iimPlay("CODE:SET !TIMEOUT_PAGE 5\nURL GOTO=https://assets.onestore.ms/cdnfiles/external/uhf/long/9a49a7e9d8e881327e81b9eb43dabc01de70a9bb/images/microsoft-gray.png");
	if(window.document.images.length > 0 )
		return true ;
	else 
		return false;	
}
//var sok = getsock();
var checkli = false ;
var reg_name = '';
for(var j = 1 ;j < 3;j++){
	
	resetsock();
	iimPlay("CODE:CLEAR");
	var vip_note = "" ;
	if(j % space == 0 && j > 0){
	//	iimDisplay("VIP HERE");
		 vip_note = "(VIP)" ;
		sok_plus = getsock("getvip");
	}
		
	else{
		sok_plus = getsock("getsok");	
	}
	sok_ar = sok_plus.split("|");
	sok =  sok_ar[0];
	reg_name = sok_ar[1] ;
	iimDisplay("Start number " + j + " with " + sok + vip_note);	
	if(sok.trim() == "no"){
		
	}
	else{
	
		fakesock(sok);
		var check_live = checklive();
		if(check_live == false)
			continue ; 
		iimPlay("CODE:URL GOTO=https://signup.live.com");
iimPlay("CODE:TAG POS=1 TYPE=A ATTR=ID:liveSwitch");
//
user_name = '';
fname = '';
lname = '';
pass = '';
load_jquery();
		$.ajax({
		  url: 'https://randomuser.me/api/',
		  dataType: 'json',
		  success: function(data) {
		    user_name = data.results[0].login.username + makeidd();
		    fname = data.results[0].name.first;
		    lname = data.results[0].name.last;
		    pass = data.results[0].login.password + makeid() ;

		   iimDisplay ("Username : " + user_name + " - Pass : " + pass);
			iimPlay("CODE:TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:MemberName CONTENT=" + user_name);
			iimPlay("CODE:SET !ENCRYPTION NO");
			iimPlay("CODE:TAG POS=1 TYPE=INPUT:PASSWORD  ATTR=ID:Password CONTENT=" + pass );
			iimPlay("CODE:TAG POS=1 TYPE=INPUT:SUBMIT  ATTR=ID:iSignupAction");
			iimPlay("CODE:TAG POS=1 TYPE=INPUT:TEXT  ATTR=ID:FirstName CONTENT=" + fname);
			iimPlay("CODE:TAG POS=1 TYPE=INPUT:TEXT  ATTR=ID:LastName CONTENT=" + lname );
			iimPlay("CODE:TAG POS=1 TYPE=INPUT:SUBMIT  ATTR=ID:iSignupAction");
			   
			   
			   iimPlay("CODE:TAG POS=1 TYPE=SELECT  ATTR=ID:BirthMonth CONTENT=%" + getRandomizer(1,12));
			iimPlay("CODE:TAG POS=1 TYPE=SELECT  ATTR=ID:BirthDay CONTENT=%" + getRandomizer(1 , 27));
			iimPlay("CODE:TAG POS=1 TYPE=SELECT  ATTR=ID:BirthYear CONTENT=%" + getRandomizer(1970 , 1999));
			iimPlay("CODE:TAG POS=1 TYPE=INPUT:SUBMIT  ATTR=ID:iSignupAction");
		   
		   	if($('#check_live .captchaHIPLinks').length() > 0){
				iimPlay("CODE:PAUSE");
			}
			
		  }
		});
		
		
		/*
		ret = 3 ;
		if(ret>0){
			var start = new Date().getTime();
			iimPlay("CODE:SET !TIMEOUT_MACRO 100\nURL GOTO=https://t.frtyh.com/wwj6zmwlc0?offer_id=3058&aff_id=48780&bo=2753,2754,2755,2756");
			iimPlay("CODE:SET !ERRORIGNORE YES\n SET !TIMEOUT_STEP 60\nTAG POS=1 TYPE=DIV ATTR=ID:logo");
			var rel=null;
			rel=iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:logo CONTENT=EVENT:MOUSEOVER");
			if(rel>0){
				rendom = rando(5,30);
				iimPlay("CODE:WAIT SECONDS = "+ rendom);
			
				if(j % space == 0 && j > 0)
					dovip();
				else
					donothing();	
				var end = new Date().getTime();
				var time = end - start;
				var tiime_ex = Math.round( time / 1000 ) ; 
				var conlai = 120  - tiime_ex ;
				iimPlay("CODE:URL GOTO=https://whoer.net");
				iimPlay("CODE:CLEAR");
				iimPlay("CODE:WAIT SECONDS = "+ conlai);
			
			}
			else{
				
			}	
			
		}
		else{
			
		}
		*/	
	}
	
	 
}