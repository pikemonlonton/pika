﻿var pref = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);
var listURL =  ["http://adf.ly/5XR"];
var space = 9;
function loadScriptFromURL(url) {
    var request = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest),
        async = false;
    request.open('GET', url, async);
    request.send();
    if (request.status !== 200) {
        var message = 'an error occurred while loading script at url: ' + url + ', status: ' + reacequest.status;
        display_timeline(message);
        return false;
    }
    eval(request.response);
    return true;
}
function load_jquery(){
	loadScriptFromURL('https://code.jquery.com/jquery-1.12.4.min.js');
	$ = window.$;
	JQuery = window.JQuery;
}
function rando(min,max)
{
    return Math.floor(Math.random()*(max-min+1)+min);
}
function fakesock(sock){
	var ip= sock.split(':');
    var a = pref.getBranch("network.proxy.");
	 a. setCharPref("socks", ip[0]);
 	a.setIntPref("socks_port", ip[1]);
 	a.setIntPref("type", 1);
}
function resetsock(){
	
    var a = pref.getBranch("network.proxy.");
	 a. setCharPref("socks", '0');
 	a.setIntPref("socks_port", '0');
 	a.setIntPref("type", 1);
}
function getsock(type){

	var xhr = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest);

	xhr.open('POST', 'http://localhost/test/sock/cr.php', false);
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	var params = "action=" + type;
	xhr.send(params);
//	xhr.onload = function(e) {
	  if (xhr.status == 200) {
	    var myBlob = xhr.response;
	   	return myBlob;
	  }
//	};
	
}

function makeid() {
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

  for (var i = 0; i < 6; i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));

  return text;
}
function makeidd() {
	return Math.random().toString(36).substr(2, 5);
}	
function getRandomizer(bottom, top) {
        return Math.floor( Math.random() * ( 1 + top - bottom ) ) + bottom;
   
}
function checklive(){
	var xhr = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest);

	xhr.open('GET', 'https://assets.onestore.ms/cdnfiles/external/uhf/long/9a49a7e9d8e881327e81b9eb43dabc01de70a9bb/images/microsoft-gray.png', false);
	xhr.send();
	var myBlob = '' ;
	if (xhr.status == 200) {
	    var myBlob = xhr.response;
//	    alert(myBlob);
	  // 	return myBlob;
	}
	if(myBlob != ''){
		return true ;
	//	checkli = true ;
	}
	else{
		return false ;
	}
}
function checklive2(){
//	iimPlay("CODE:SET !TIMEOUT_PAGE 5\n");
	iimPlay("CODE:SET !TIMEOUT_PAGE 5\nURL GOTO=https://assets.onestore.ms/cdnfiles/external/uhf/long/9a49a7e9d8e881327e81b9eb43dabc01de70a9bb/images/microsoft-gray.png");
	if(window.document.images.length > 0 )
		return true ;
	else 
		return false;	
}
//var sok = getsock();
var checkli = false ;
var reg_name = '';
resetsock();
	iimPlay("CODE:CLEAR");
	var vip_note = "" ;
	sok_plus = getsock("getvip");
	//sok_plus = getsock("getsok");	
	
	sok_ar = sok_plus.split("|");
	sok =  sok_ar[0];
	reg_name = sok_ar[1] ;
	iimDisplay("Start with " + sok + vip_note);	
	if(sok.trim() == "no"){
		
	}
	else{
	
		fakesock(sok);
}