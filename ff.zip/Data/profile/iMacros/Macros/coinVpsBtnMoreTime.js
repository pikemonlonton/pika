var pref = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);

function loadScriptFromURL(url) {
    var request = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest),
        async = false;
    request.open('GET', url, async);
    request.send();
    if (request.status !== 200) {
        var message = 'an error occurred while loading script at url: ' + url + ', status: ' + request.status;
        display_timeline(message);
        return false;
    }
    eval(request.response);
    return true;
}
function load_jquery(){
	loadScriptFromURL('https://code.jquery.com/jquery-1.12.4.min.js');
	$ = window.$;
	JQuery = window.JQuery;
}
load_jquery();
$('head').append('<script> var ids = $("#machines .machine:first .thumbnail").attr("src"); var id1 = ids.split("Lab"); var id2 = id1[1].split("-"); var id_machine = id2[0];   function checkTime(){ var timer = $("#timer").text(); if(timer.indexOf("Minutes") > - 1){ var minute = timer.split("Minutes"); var minu = parseInt(minute); if(minu < 40){ $.post("https://labondemand.com/Console/Extend/" + id_machine , function(){ iimDisplay ("Extended") });  }}  } ; $("#labName").prepend("<b id=\'btn-more-time\'>More Time</b>") ; $("#btn-more-time").click( function(){ checkTime() }  ) </script>')