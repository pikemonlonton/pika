﻿
   var pref = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);

function loadScriptFromURL(url) {
    var request = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest),
        async = false;
    request.open('GET', url, async);
    request.send();
    if (request.status !== 200) {
        var message = 'an error occurred while loading script at url: ' + url + ', status: ' + request.status;
        display_timeline(message);
        return false;
    }
    eval(request.response);
    return true;
}
function getCookie(){
	var xhr = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest);
	xhr.open('POST', 'http://thuenhahn.com/temp/getcookie.php', false);
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	var params = "action=import";
	xhr.send(params);
	var myBlob = '' ; 
	if (xhr.status == 200) {
	    myBlob = xhr.response;
	}
	return myBlob ; 
}
function export_to_server(string_cookie){
	var xhr = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest);
	xhr.open('POST', 'http://localhost/getcookie.php', false);
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	var params = "action=export&cc=" + string_cookie;
	xhr.send(params);
	if (xhr.status == 200) {
	     display_timeline("Exported");
	}
}
coco =  getCookie() ;

    var endl = "\n";


    // Return a string containing the formatted error info.
    // in: err(Error)
    // return message(string)
    function formatErr(err)
    {
        var message = "--- Exception " + ( err && err.name ? err.name : "<Unknown>") + " ---" + endl;
       
        if(err)
        {
            message += endl + (err.message ? err.message : "") + endl;
            message += endl + (err.stack ? err.stack : "") + endl;
        }
        else
        {
            message += "No error information provided.";
        }
       
        return message;
    }


    // Log a message to Firefox's browser console.
    // https://developer.mozilla.org/en-US/docs/Components.utils.reportError
    function console(aMessage) {
        var consoleService = Components.classes["@mozilla.org/consoleservice;1"]
            .getService(Components.interfaces.nsIConsoleService);
        consoleService.logStringMessage("iMacros: " + aMessage);
    }


    // Log a message to iMacros' display and Firefox's browser console.
    function log(message)
    {
        iimDisplay(message);
        console(message);
    }


    // Log a message to iMacros' display, Firefox's browser console and display it via alert()
    function logAlert(message)
    {
        log(message);
        alert(message);
    }


    //
    //
    // wrap all code in a try/catch
    //
    //
    try {
    // anonymous function allows use of return statement and making a function call before it's defined.
    (function () {

    var dateobj = new Date();
    var isodate = dateobj.toISOString();
    log("Started script " + endl + isodate);

    const folder = "D:\\";



    //
    // YOUR CODE GOES HERE.
    //

	
	
  //  exportCookies("cookies.txt");
    clearCookies();
    importCookies("cookies.txt");




    // Import cookies.
    //
    // return none
    // fatal: failed to import cookies
    //
    // if filename does not exist no cookies are imported
	
    function importCookies(filename)
    {
	//	alert(coco);
	/*
        var file = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsILocalFile);
        file.initWithPath(folder + "Cookies\\" + filename);
        if(!file.exists())
        {
            console("Cookies filename " + filename + " does not exist!");
            return;
        }
       
        // Open the selected file
        var istream = Components.classes["@mozilla.org/network/file-input-stream;1"].createInstance(Components.interfaces.nsIFileInputStream);
        istream.init(file, 0x01, 0444, 0); // readonly
        // Select nsILineInputStream interface for "readline()" usage
        istream.QueryInterface(Components.interfaces.nsILineInputStream);

        // Open CookieManager connection
        var cm = Components.classes["@mozilla.org/cookiemanager;1"].getService(Components.interfaces.nsICookieManager2);
        if(!cm){
            throw new Error("Could not load nsICookieManager2");
        }

        var line = {}, cookieNum, fields, hasmore;
        var cHost, cPath, cName, cValue, cSecure, cSession, cExpiry;
        cookieNum = 0;
		*/
		
		// Open CookieManager connection
        var cm = Components.classes["@mozilla.org/cookiemanager;1"].getService(Components.interfaces.nsICookieManager2);
        if(!cm){
            throw new Error("Could not load nsICookieManager2");
        }
		 var cHost, cPath, cName, cValue, cSecure, cSession, cExpiry;
        cookieNum = 0;
		var one_cookie = coco.split("meobr");
		for(i = 0 ; i < one_cookie.length ; i++){
			var fields = one_cookie[i].split(" | ", 7);
            cHost    = fields[0];
            cPath    = fields[2];
            cName    = fields[5];
            cValue   = fields[6];
            cSecure  = (fields[3] == "TRUE");
            cExpiry  = parseInt(fields[4]);
            // Expiry == 0 means this is a session cookie
            cSession = (cExpiry == 0);
            // This is so weird! cm.add() won't take cSession=TRUE and cExpiry=0
            // because cExpiry < Today! So we work around this by making the cookie
            // expire Sonntag, Feb. 7 2106 07:28:15. See you then ;-)
            if(!cExpiry)
                cExpiry = 0xffffffff;
           
            // Add that cookie using the CookieManager
            cm.add(cHost, cPath, cName, cValue, cSecure, false, cSession, cExpiry);
		}
		
		/* One line from cookies.txt looks like ...
            * .google.com  TRUE     /     FALSE      0      someID 4815162342
            *  <host>    <domain> <path>  <ssl>   <expiry>  <name>  <value>
            *    0          1       2       3        4         5       6
            */
			/*
        do{
            
            hasmore = istream.readLine(line);
            var fields = line.value.split("\t", 7);
            if(fields.length != 7)
                continue;
           
            // Read needed fields
            cHost    = fields[0];
            cPath    = fields[2];
            cName    = fields[5];
            cValue   = fields[6];
            cSecure  = (fields[3] == "TRUE");
            cExpiry  = parseInt(fields[4]);
            // Expiry == 0 means this is a session cookie
            cSession = (cExpiry == 0);
            // This is so weird! cm.add() won't take cSession=TRUE and cExpiry=0
            // because cExpiry < Today! So we work around this by making the cookie
            // expire Sonntag, Feb. 7 2106 07:28:15. See you then ;-)
            if(!cExpiry)
                cExpiry = 0xffffffff;
           
            // Add that cookie using the CookieManager
            cm.add(cHost, cPath, cName, cValue, cSecure, false, cSession, cExpiry);
           
            cookieNum++;
        }while(hasmore);
		*/
    //    istream.close();
    //    console("Imported " + cookieNum + " cookies from " + filename);
    }


    // Export cookies.
    //
    // return none
    // fatal: failed to export cookies
    //
    // if no cookies exist filename is not written
    
    function clearCookies()
    {
        if(iimPlay("CODE:CLEAR") !== 1)
        {
            throw new Error("iimPlay() failed (see sidebar)");
        }
    }


    // END CODE HERE
    })(); // end of anonymous function
    } catch(err) {
        var message = formatErr(err);
        console(message);
        throw err;
    }


