var pref = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);

function loadScriptFromURL(url) {
    var request = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest),
        async = false;
    request.open('GET', url, async);
    request.send();
    if (request.status !== 200) {
        var message = 'an error occurred while loading script at url: ' + url + ', status: ' + request.status;
        display_timeline(message);
        return false;
    }
    eval(request.response);
    return true;
}
function load_jquery(){
	loadScriptFromURL('https://code.jquery.com/jquery-1.12.4.min.js');
	$ = window.$;
	JQuery = window.JQuery;
}


count = 0 ; 
var loopmeo ; 
load_jquery();
$('<h3><b id="stopmeo" style="cursor:pointer">Stop</b><h3>').appendTo('#machines');
/*
var logout_machine = prompt('Input position logout ( seperate with , )');
var lo_array = logout_machine.split(',');
*/
var ids = $('#machines .machine:first .thumbnail').attr('src');
var id1 = ids.split('Lab');
var id2 = id1[1].split('-');
var id_machine = id2[0];

var total_machine = $('.machineName').length ; 

var address = window.location.href  ; 
var kem = address.split('/');
sku = kem[kem.length - 1] ; 
sku = sku.substring(0, 5); 
function ping(){
	var xhr = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest);
	xhr.open('POST', 'http://thuenhahn.com/temp/planb.php', false);
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	var params = "action=ping&sku="+sku;
	xhr.send(params);
	if (xhr.status == 200) {
	    // iimDisplay("Exported");
		// alert(xhr.response);
	}
}

function start() {
//	ping() ; 
	var tem = count + 1 ;
	iimDisplay ("Start " + tem)
	
	
	
	var bonus  = Math.floor((Math.random() * 5) + 1);
	iimPlay("CODE:TAG POS="+bonus+" TYPE=DIV ATTR=CLASS:machineName");
	iimPlay("CODE:WAIT SECONDS = 6");
	if($("#startMachine").is(":visible")){
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:startMachine") ;
	}
	iimPlay("CODE:WAIT SECONDS = 3");
	iimPlay("CODE:TAG POS=6 TYPE=DIV ATTR=CLASS:machineName");
	iimPlay("CODE:WAIT SECONDS = 3");
	if($("#startMachine").is(":visible")){
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:startMachine") ;
	}
	/*
	for (var i = 1 ; i < total_machine + 1; i++) {
		iimPlay("CODE:TAG POS="+i+" TYPE=DIV ATTR=CLASS:machineName");
		iimPlay("CODE:WAIT SECONDS = 6");
		if($("#startMachine").is(":visible")){
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:startMachine") ;
		}
		iimPlay("CODE:WAIT SECONDS = 3");
	}
  */
  	var timer = $('#timer').text();
  	if(timer.indexOf('Minutes') > - 1){
		var minute = timer.split('Minutes');
		var minu = parseInt(minute);
		
		
		if(minu < 40){
			$.post("https://labondemand.com/Console/Extend/" + id_machine , function(){
				iimDisplay ("Extended")
				
			});
		}
		
	}
   loopmeo = window.setTimeout(start, 120000);
}

// boot up the first call
start();
$('#stopmeo').click(function(){
	 iimDisplay('Stopped');
	 window.clearTimeout(loopmeo);
})
