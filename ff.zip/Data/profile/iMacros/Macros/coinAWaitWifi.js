﻿/*
var pref = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);

function loadScriptFromURL(url) {
    var request = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest),
        async = false;
    request.open('GET', url, async);
    request.send();
    if (request.status !== 200) {
        var message = 'an error occurred while loading script at url: ' + url + ', status: ' + request.status;
        display_timeline(message);
        return false;
    }
    eval(request.response);
    return true;
}
function load_jquery(){
	loadScriptFromURL('https://code.jquery.com/jquery-1.12.4.min.js');
	$ = window.$;
	JQuery = window.JQuery;
}

load_jquery();

		*/
		
		function set_point(){
			var now_style = window.document.getElementById("vmWrapper").getAttribute("style");
			var style_more  = now_style + " ; pika:chu" ;
			window.document.getElementById("vmWrapper").setAttribute("style" , style_more);
		 }
		 function reset_point(){
			 var now_style = window.document.getElementById("vmWrapper").getAttribute("style");
			//var style_more  = now_style + " ; pika:chu" ;
			style_more  =now_style.replace("pika:chu", "");
			window.document.getElementById("vmWrapper").setAttribute("style" , style_more);
			
		 }
		 function check_load(){
			 iimPlay("CODE:WAIT SECONDS = 2");
			 var now_style = window.document.getElementById("vmWrapper").getAttribute("style");
			// alert(now_style.indexOf('chu'))
			 if( now_style.indexOf('chu') >= 0){
				 check_load();
			 }
			 else{
			//	 alert('pik');
			 }
		 }

		var today = new Date();
		var dd = today.getDate();
		var mm = today.getMonth()+1; //January is 0!

		var yyyy = today.getFullYear();
		if(dd<10){
			dd='0'+dd;
		} 
		if(mm<10){
			mm='0'+mm;
		} 
		var today = mm+'/'+dd+'/'+yyyy;


	var temp = window.content.document.getElementById('machines');
	child = temp.children;
	total_machine = child.length ;
	for(j = 1 ; j < total_machine + 1 ; j++){
		
		if(j == 1 ){
				 iimPlay("CODE:TAG POS=6 TYPE=DIV ATTR=CLASS:machineName");
				 iimPlay("CODE:WAIT SECONDS = 2");
				 reset_point()

			 }
		
		iimPlay("CODE:TAG POS="+j+" TYPE=DIV ATTR=CLASS:machineName");
		set_point() ; 
				check_load();
		
		if(j < total_machine){
			
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:windowsKeyR ");
			iimPlay("CODE:WAIT SECONDS = 2");
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
			iimPlay("CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT=ncpa.cpl ");
			iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
			iimPlay("CODE:WAIT SECONDS = 2");
			iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
			iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
			iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
			iimPlay("CODE:WAIT SECONDS = 3");
			iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:39');
			iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
			iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		}
		
		if( j == 1 ){
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:windowsKeyR ");
			iimPlay("CODE:WAIT SECONDS = 2");
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
			iimPlay("CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT=cmd ");
			iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
			iimPlay("CODE:WAIT SECONDS = 2");
			iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
			iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
			iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
			iimPlay("CODE:WAIT SECONDS = 4");
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
			iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="date '+today+'"');
			iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
			iimPlay("CODE:WAIT SECONDS = 2");
			iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
			iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
			iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
			iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
			iimPlay("CODE:WAIT SECONDS = 4");
		}
		
		
		if(j == total_machine ){
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:windowsKeyR ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay("CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT=cmd ");
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 4");

		// cd C:/
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="powershell -NoExit -Command \'Set-Location C: \' ;"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 4");

		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="Set-ItemProperty -Path \'HKLM:/\SOFTWARE/\Microsoft/\Windows NT/\CurrentVersion/\Winlogon/\' -Name AutoAdminLogon  -Value 1 ; Set-ItemProperty -Path \'HKLM:/\SOFTWARE/\Microsoft/\Windows NT/\CurrentVersion/\Winlogon/\' -Name DefaultDomainName  -Value CONTOSO ;Set-ItemProperty -Path \'HKLM:/\SOFTWARE/\Microsoft/\Windows NT/\CurrentVersion/\Winlogon/\' -Name DefaultUserName  -Value Administrator ;Set-ItemProperty -Path \'HKLM:/\SOFTWARE/\Microsoft/\Windows NT/\CurrentVersion/\Winlogon/\' -Name DefaultPassword  -Value pass@word1 ;"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 18");
		
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');

		
		}
	}
		
		iimPlay("CODE:URL GOTO=imacros://run/?m=coinAwaitSetUpAll.js");
		
