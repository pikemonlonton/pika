﻿

var out_x = 1506;
var out_y = 94;
var in_x = 1065;
var in_y = 175;
for(i = 0 ; i < 100 ; i++){
	var ro = i % 3 ;
	
	if(ro == 1 ){
		iimPlay("CODE:TAG POS=3 TYPE=DIV ATTR=TXT:AAD-DC1");
	}
	else if(ro == 2 ){
		iimPlay("CODE:TAG POS=3 TYPE=DIV ATTR=TXT:AAD-SRV1");
	}
	else{
		iimPlay("CODE:TAG POS=3 TYPE=DIV ATTR=TXT:AAD-SRV2");
	}
	iimPlay('CODE:WAIT SECONDS = 300');
	
}

