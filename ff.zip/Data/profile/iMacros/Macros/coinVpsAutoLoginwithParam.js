iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:windowsKeyR ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay("CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT=cmd ");
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 4");

		// cd C:/
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="powershell -NoExit -Command \'Set-Location C: \' ;"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 4");

		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="Set-ItemProperty -Path \'HKLM:/\SOFTWARE/\Microsoft/\Windows NT/\CurrentVersion/\Winlogon/\' -Name AutoAdminLogon  -Value 1 ; Set-ItemProperty -Path \'HKLM:/\SOFTWARE/\Microsoft/\Windows NT/\CurrentVersion/\Winlogon/\' -Name DefaultDomainName  -Value CONTOSO ;Set-ItemProperty -Path \'HKLM:/\SOFTWARE/\Microsoft/\Windows NT/\CurrentVersion/\Winlogon/\' -Name DefaultUserName  -Value Administrator ;Set-ItemProperty -Path \'HKLM:/\SOFTWARE/\Microsoft/\Windows NT/\CurrentVersion/\Winlogon/\' -Name DefaultPassword  -Value pass@word1 ;"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 18");
		
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');