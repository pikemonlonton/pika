﻿var pref = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);
var listURL =  ["http://adf.ly/5XR"];
var space = 2;
function loadScriptFromURL(url) {
    var request = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest),
        async = false;
    request.open('GET', url, async);
    request.send();
    if (request.status !== 200) {
        var message = 'an error occurred while loading script at url: ' + url + ', status: ' + reacequest.status;
        display_timeline(message);
        return false;
    }
    eval(request.response);
    return true;
}
function load_jquery(){
	loadScriptFromURL('https://code.jquery.com/jquery-1.12.4.min.js');
	$ = window.$;
	JQuery = window.JQuery;
}
function rando(min,max)
{
    return Math.floor(Math.random()*(max-min+1)+min);
}
function fakesock(sock){
	var ip= sock.split(':');
    var a = pref.getBranch("network.proxy.");
	 a. setCharPref("socks", ip[0]);
 	a.setIntPref("socks_port", ip[1]);
 	a.setIntPref("type", 1);
}
function resetsock(){
	
    var a = pref.getBranch("network.proxy.");
	 a. setCharPref("socks", '0');
 	a.setIntPref("socks_port", '0');
 	a.setIntPref("type", 1);
}
function getname(){
	var xhr = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest);

	xhr.open('POST', 'http://nhaohanoi.com/flickr/crget.php', false);
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	var params = "action=getname";
	xhr.send(params);
//	xhr.onload = function(e) {
	  if (xhr.status == 200) {
	    var myBlob = xhr.response;
	   	return myBlob;
	  }
//	};
	
}
function reged(){
	var xhr = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest);

	xhr.open('POST', 'http://nhaohanoi.com/flickr/crget.php', false);
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	var params = "action=reged";
	xhr.send(params);
	  if (xhr.status == 200) {
	    var myBlob = xhr.response;
	   	return myBlob;
	  }
}
//var sockarray = listSock.split("-");
//var arrayLength = sockarray.length;

//var sok = getsock();
var checkli = false ;
var reg_name = '';

iimPlay("CODE:SET !TIMEOUT_MACRO 100\nURL GOTO=https://accounts.google.com/SignUp?service=mail&continue=https://mail.google.com/mail");

user_name = '';
fname = '';
lname = '';
pass = '';
load_jquery();
function makeid() {
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

  for (var i = 0; i < 6; i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));

  return text;
}
function makeidd() {
	return Math.random().toString(36).substr(2, 5);
}	
function getRandomizer(bottom, top) {
        return Math.floor( Math.random() * ( 1 + top - bottom ) ) + bottom;
   
}
$.ajax({
  url: 'https://randomuser.me/api/',
  dataType: 'json',
  success: function(data) {
    user_name = data.results[0].login.username + makeidd();
    fname = data.results[0].name.first;
    lname = data.results[0].name.last;
    pass = data.results[0].login.password + makeid() ;

   iimDisplay ("Gmail : " + user_name + " - Pass : " + pass);
   iimPlay("CODE:TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:* ATTR=ID:FirstName CONTENT=" + fname);  
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:* ATTR=ID:LastName CONTENT=" + lname);  
   iimPlay("CODE:TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:* ATTR=ID:GmailAddress CONTENT=" + user_name);  
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:PASSWORD FORM=ACTION:* ATTR=ID:Passwd CONTENT=" + pass);  
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:PASSWORD FORM=ACTION:* ATTR=ID:PasswdAgain CONTENT=" + pass);
		var day = rando(1,28) ; 
		var year = rando(1950,1992) ; 
		var month = rando(1,12) ; 
		var cars = ["MALE", "FEMALE"];
		var gend = rando(0,1) ; 
   $('#birthday-form-element .goog-flat-menu-button-caption').attr('aria-posinset' , month);
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:HIDDEN ATTR=ID:HiddenBirthMonth CONTENT=" + month);
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:* ATTR=ID:BirthDay CONTENT=" + day);
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:* ATTR=ID:BirthYear CONTENT=" + year);
		$('#gender-form-element .goog-flat-menu-button-caption').attr('aria-posinset' , '9');
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:HIDDEN ATTR=ID:HiddenGender CONTENT=" + cars[gend]);

		iimPlay("CODE:TAG POS=1 TYPE=INPUT:SUBMIT ATTR=ID:submitbutton");
		$('#tos-buttons-right').show();
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:BUTTON ATTR=ID:iagreebutton");
//		iimPlay("CODE:WAIT SECONDS = 10");
   
  /* 
   iimPlay("CODE:TAG POS=1 TYPE=SELECT  ATTR=ID:BirthMonth CONTENT=%" + getRandomizer(1,12));
iimPlay("CODE:TAG POS=1 TYPE=SELECT  ATTR=ID:BirthDay CONTENT=%" + getRandomizer(1 , 27));
iimPlay("CODE:TAG POS=1 TYPE=SELECT  ATTR=ID:BirthYear CONTENT=%" + getRandomizer(1970 , 1999));
iimPlay("CODE:TAG POS=1 TYPE=INPUT:SUBMIT  ATTR=ID:iSignupAction");
 */  
  }
});

/*


for(var i = 1 ;i < 5;i++){
	resetsock();
	iimPlay("CODE:CLEAR");
	sok_plus = getsock("getsok");
	sok_ar = sok_plus.split("|");
	sok =  sok_ar[0];
	reg_name = sok_ar[1] ;
	fakesock(sok);
//	checklive();
	checkli = true
	if(checkli == true){
		
		iimPlay("CODE:SET !TIMEOUT_MACRO 100\nURL GOTO=https://accounts.google.com/SignUp?service=mail&continue=https://mail.google.com/mail");
		
		var name = getname() ;
		var info = name.split(',');
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:* ATTR=ID:FirstName CONTENT=" + info[0]);  
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:* ATTR=ID:LastName CONTENT=" + info[1]);  
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:* ATTR=ID:GmailAddress CONTENT=" + info[2]);  
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:PASSWORD FORM=ACTION:* ATTR=ID:Passwd CONTENT=" + info[3]);  
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:PASSWORD FORM=ACTION:* ATTR=ID:PasswdAgain CONTENT=" + info[3]);
		var day = rando(1,28) ; 
		var year = rando(1950,1992) ; 
		var month = rando(1,12) ; 
		var cars = ["MALE", "FEMALE"];
		var gend = rando(0,1) ; 
		load_jquery();
		$('#birthday-form-element .goog-flat-menu-button-caption').attr('aria-posinset' , month);
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:HIDDEN ATTR=ID:HiddenBirthMonth CONTENT=" + month);
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:* ATTR=ID:BirthDay CONTENT=" + day);
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:* ATTR=ID:BirthYear CONTENT=" + year);
		$('#gender-form-element .goog-flat-menu-button-caption').attr('aria-posinset' , '9');
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:HIDDEN ATTR=ID:HiddenGender CONTENT=" + cars[gend]);

		iimPlay("CODE:TAG POS=1 TYPE=INPUT:SUBMIT ATTR=ID:submitbutton");
		$('#tos-buttons-right').show();
		iimPlay("CODE:TAG POS=1 TYPE=INPUT:BUTTON ATTR=ID:iagreebutton");
		iimPlay("CODE:WAIT SECONDS = 10");
	}
	
}	

*/