﻿/*iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
			string = "Copy-Item -Path /\/\w15-dc\/tool\/tem.exe -Destination c:/\gem.exe ; & 'C:/\gem.exe' ; Start-Sleep -s 9 ; & 'C:/etn_startup.exe' ; cd C:/ ; cmd.exe /c 'C:/star-etn' ; ";
			iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="'+string+'"');
			iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
			iimPlay("CODE:WAIT SECONDS = 4");
			iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
			iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
			iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
			iimPlay("CODE:WAIT SECONDS = 200");
*/
var temp = window.content.document.getElementById('machines');
	child = temp.children;
	total_machine = child.length ;
	function set_point(){
			var now_style = window.document.getElementById("vmWrapper").getAttribute("style");
			var style_more  = now_style + " ; pika:chu" ;
			window.document.getElementById("vmWrapper").setAttribute("style" , style_more);
		 }
		 function reset_point(){
			 var now_style = window.document.getElementById("vmWrapper").getAttribute("style");
			//var style_more  = now_style + " ; pika:chu" ;
			style_more  =now_style.replace("pika:chu", "");
			window.document.getElementById("vmWrapper").setAttribute("style" , style_more);
			
		 }
		 function check_load(){
			 iimPlay("CODE:WAIT SECONDS = 2");
			 var now_style = window.document.getElementById("vmWrapper").getAttribute("style");
			// alert(now_style.indexOf('chu'))
			 if( now_style.indexOf('chu') >= 0){
				 check_load();
			 }
			 else{
			//	 alert('pik');
			 }
		 }
	for(j = 1 ; j < total_machine + 1  ; j++){
		if(j == 1 ){
				 iimPlay("CODE:TAG POS=6 TYPE=DIV ATTR=CLASS:machineName");
				 iimPlay("CODE:WAIT SECONDS = 2");
				 reset_point()

			 }
		iimPlay("CODE:TAG POS="+j+" TYPE=DIV ATTR=CLASS:machineName");
		set_point() ; 
		check_load();
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:windowsKeyR ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay("CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT=cmd ");
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 2");

		// cd C:/
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="powershell -NoExit -Command \'Set-Location C: \' "');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 2");
		
		if(j ==1){
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
			iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="NET SHARE tool=C:\ /GRANT:Everyone`,READ"');
			iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
			iimPlay("CODE:WAIT SECONDS = 2");
			iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
			iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
			iimPlay("CODE:WAIT SECONDS = 5");

			var share_string = "regsvr32 hnetcfg.dll ; $m = New-Object -ComObject HNetCfg.HNetShare ; $c = $m.EnumEveryConnection |? { $m.NetConnectionProps.Invoke($_).Name -eq 'VPN - VPN Client' } ; $config = $m.INetSharingConfigurationForINetConnection.Invoke($c) ; $config.EnableSharing(0) ; " ;
			share_string += "$c = $m.EnumEveryConnection |? { $m.NetConnectionProps.Invoke($_).Name -eq 'Local Area Connection' } ; $config = $m.INetSharingConfigurationForINetConnection.Invoke($c) ; $config.EnableSharing(1)" ;
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
			iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="'+share_string+'"');
			iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
			iimPlay("CODE:WAIT SECONDS = 16");
			iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
			iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
			iimPlay("CODE:WAIT SECONDS = 5");
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		}
		else{
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
			string = "netsh interface set interface 'WebNet' disabled ;   $wmi = Get-WmiObject win32_networkadapterconfiguration ; $wmi.EnableStatic('192.168.137."+j+"', '255.255.255.0') ; $wmi.SetGateways('192.168.137.1', 1) ; $wmi.SetDNSServerSearchOrder('192.168.137.1') ;";
			iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="'+string+'"');
			iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
			iimPlay("CODE:WAIT SECONDS = 2");
			iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
			iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
			iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
			iimPlay("CODE:WAIT SECONDS = 8");
			
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
			iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
			string = "Copy-Item -Path /\/\w15-dc\/tool\/tem.exe -Destination c:/\gem.exe ; & 'C:/\gem.exe' ; Start-Sleep -s 9 ; & 'C:/etn_startup.exe' ; cd C:/ ; cmd.exe /c 'C:/star-etn' ; ";
			iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="'+string+'"');
			iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
			iimPlay("CODE:WAIT SECONDS = 4");
			iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
			iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
			iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
			iimPlay("CODE:WAIT SECONDS = 2");
		}
	}
	iimPlay("CODE:URL GOTO=imacros://run/?m=coinVpsExpired.js");