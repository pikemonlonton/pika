function create_random(maxv){
	return Math.floor(Math.random() * maxv) + 1;
}

for(i = 0 ; i < 30 ; i++){
	iimPlay("CODE:WAIT SECONDS = 8")
	var count =   window.content.document.getElementsByTagName('a').length;
	var pos = create_random(count );
	iimPlay("CODE:TAG POS="+pos+" TYPE=A ATTR=TXT:*");
}
